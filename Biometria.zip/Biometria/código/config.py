import os

PASTA_CODIGO = os.path.dirname(os.path.abspath(__file__))
PASTA_RAIZ = os.path.dirname(PASTA_CODIGO)
CAMINHO_BANCO = os.path.join(PASTA_RAIZ, "mma_sistema.db")
PASTA_FOTOS = os.path.join(PASTA_RAIZ, "fotos")

MODELO_FACIAL = "ArcFace"
DETECTOR_FACIAL = "opencv"
ANTI_SPOOFING = False

LIMITE_TENTATIVAS = 3
BLOQUEIO_SEGUNDOS = 60