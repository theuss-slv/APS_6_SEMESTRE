import os
import sqlite3
import sys
import time
from contextlib import closing
from tkinter import messagebox

import customtkinter as ctk

# Garante que o Python procura módulos na pasta do próprio script
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from biometria import (
    CANCELADO,
    CONCEDIDO,
    NEGADO,
    autenticar_webcam,
    cadastrar_novo_rosto,
)
from config import BLOQUEIO_SEGUNDOS, CAMINHO_BANCO, LIMITE_TENTATIVAS

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

TITULOS_PAINEL = {
    1: "Painel Nível 1 - Informações Gerais",
    2: "Painel Nível 2 - Diretores de Divisão",
    3: "Painel Nível 3 - Ministro do Meio Ambiente",
}


class AppAPS(ctk.CTk):

  def __init__(self):
    super().__init__()

    self.title("Ministério do Meio Ambiente - Sistema de Autenticação Biométrica")
    self.geometry("750x550")
    self.resizable(False, False)

    self.usuario_dados = None
    self.frame_tabela = None
    self.tentativas = {}  # username -> falhas seguidas
    self.bloqueios = {}  # username -> momento em que o bloqueio termina

    self.container = ctk.CTkFrame(self)
    self.container.pack(fill="both", expand=True, padx=20, pady=20)

    self.mostrar_tela_inicial()

  def limpar_container(self):
    for widget in self.container.winfo_children():
      widget.destroy()
    self.frame_tabela = None

  # ---------- BANCO DE DADOS ----------
  def consultar_usuario(self, username):
    with closing(sqlite3.connect(CAMINHO_BANCO)) as conn:
      return conn.execute(
          "SELECT username, nome_completo, cargo, nivel_acesso, foto_path "
          "FROM usuarios WHERE username = ?",
          (username,),
      ).fetchone()

  def registrar_log(self, username, nivel, status):
    with closing(sqlite3.connect(CAMINHO_BANCO)) as conn:
      with conn:
        conn.execute(
            "INSERT INTO logs_acesso (username, nivel_usuario, status) "
            "VALUES (?, ?, ?)",
            (username, nivel, status),
        )

  def buscar_propriedades(self, nivel_usuario, nivel_solicitado):
    if nivel_solicitado > nivel_usuario:
      return []
    with closing(sqlite3.connect(CAMINHO_BANCO)) as conn:
      return conn.execute(
          "SELECT nome_fazenda, proprietario, localizacao, "
          "agrotoxico_proibido, impacto_hidrico "
          "FROM propriedades WHERE nivel_sigilo = ?",
          (nivel_solicitado,),
      ).fetchall()

  # ---------- 1. TELA INICIAL ----------
  def mostrar_tela_inicial(self):
    self.limpar_container()
    self.usuario_dados = None

    ctk.CTkLabel(
        self.container,
        text="Sistema de Acesso - MMA",
        font=ctk.CTkFont(size=24, weight="bold"),
    ).pack(pady=(40, 20))

    ctk.CTkLabel(
        self.container,
        text="Informe o nome do seu usuário para iniciar a autenticação:",
        font=ctk.CTkFont(size=14),
    ).pack(pady=10)

    self.entry_usuario = ctk.CTkEntry(
        self.container,
        placeholder_text="Ex: ministro, diretor, analista",
        width=300,
    )
    self.entry_usuario.pack(pady=15)
    self.entry_usuario.bind("<Return>", lambda event: self.processar_login())

    ctk.CTkButton(
        self.container, text="ENTRAR", command=self.processar_login, width=200
    ).pack(pady=20)

  def processar_login(self):
    user_input = self.entry_usuario.get().strip().lower()

    if not user_input:
      messagebox.showwarning("Aviso", "Por favor, digite um usuário!")
      return

    user = self.consultar_usuario(user_input)
    if user:
      self.usuario_dados = {
          "username": user[0],
          "nome": user[1],
          "cargo": user[2],
          "nivel": user[3],
          "foto_path": user[4],
      }
      self.mostrar_autenticacao_biometrica()
    else:
      self.registrar_log(user_input, 0, "Usuário Inexistente")
      messagebox.showerror("Erro", "Usuário não encontrado no banco de dados!")

  # ---------- 2. AUTENTICAÇÃO BIOMÉTRICA E CADASTRO ----------
  def mostrar_autenticacao_biometrica(self):
    self.limpar_container()

    ctk.CTkLabel(
        self.container,
        text="Autenticação Biométrica Facial",
        font=ctk.CTkFont(size=22, weight="bold"),
    ).pack(pady=(30, 10))

    ctk.CTkLabel(
        self.container,
        text=(
            f"Usuário: {self.usuario_dados['nome']}\n"
            f"Cargo: {self.usuario_dados['cargo']} "
            f"(Nível {self.usuario_dados['nivel']})\n\n"
            "Escolha uma das opções abaixo:"
        ),
        font=ctk.CTkFont(size=14),
    ).pack(pady=15)

    ctk.CTkButton(
        self.container,
        text="📸 Abrir Câmera para Biometria",
        fg_color="green",
        hover_color="darkgreen",
        width=250,
        height=40,
        command=self.executar_biometria,
    ).pack(pady=10)

    ctk.CTkButton(
        self.container,
        text="📝 Cadastrar / Atualizar Rosto",
        fg_color="darkblue",
        hover_color="blue",
        width=250,
        height=40,
        command=self.executar_cadastro_facial,
    ).pack(pady=10)

    ctk.CTkButton(
        self.container,
        text="Voltar",
        fg_color="gray",
        command=self.mostrar_tela_inicial,
    ).pack(pady=10)

  def executar_cadastro_facial(self):
    username = self.usuario_dados["username"]
    sucesso, mensagem = cadastrar_novo_rosto(username)
    if sucesso:
      messagebox.showinfo("Sucesso", mensagem)
    else:
      messagebox.showerror("Erro no Cadastro", mensagem)

  def segundos_de_bloqueio(self, username):
    restante = self.bloqueios.get(username, 0) - time.time()
    return int(restante) + 1 if restante > 0 else 0

  def executar_biometria(self):
    username = self.usuario_dados["username"]
    nivel = self.usuario_dados["nivel"]

    espera = self.segundos_de_bloqueio(username)
    if espera > 0:
      messagebox.showwarning(
          "Acesso Bloqueado",
          f"Muitas tentativas falhas. Aguarde {espera}s para tentar de novo.",
      )
      return

    status, mensagem = autenticar_webcam(self.usuario_dados["foto_path"])
    self.registrar_log(username, nivel, status)

    if status == CONCEDIDO:
      self.tentativas[username] = 0
      messagebox.showinfo("Sucesso", mensagem)
      self.redirecionar_menu()

    elif status == NEGADO:
      falhas = self.tentativas.get(username, 0) + 1
      self.tentativas[username] = falhas
      restantes = LIMITE_TENTATIVAS - falhas
      if restantes <= 0:
        self.tentativas[username] = 0
        self.bloqueios[username] = time.time() + BLOQUEIO_SEGUNDOS
        self.registrar_log(username, nivel, "Bloqueado")
        messagebox.showerror(
            "Acesso Bloqueado",
            f"{mensagem}\n\nLimite de tentativas atingido. Aguarde"
            f" {BLOQUEIO_SEGUNDOS}s.",
        )
      else:
        messagebox.showerror(
            "Falha na Biometria",
            f"{mensagem}\n\nTentativas restantes: {restantes}",
        )

    elif status == CANCELADO:
      messagebox.showinfo("Cancelado", mensagem)

    else:
      messagebox.showerror("Erro", mensagem)

  # ---------- 3. PAINÉIS POR NÍVEL ----------
  def redirecionar_menu(self):
    nivel = self.usuario_dados["nivel"]
    if nivel in TITULOS_PAINEL:
      self.mostrar_menu(nivel)
    else:
      messagebox.showerror(
          "Erro", f"Nível de acesso inválido ({nivel}). Procure o administrador."
      )
      self.mostrar_tela_inicial()

  def mostrar_menu(self, nivel):
    self.limpar_container()
    self.criar_cabecalho_nivel(TITULOS_PAINEL[nivel])

    if nivel > 1:
      for n in range(1, nivel + 1):
        if n == 3:
          btn = ctk.CTkButton(
              self.container,
              text="⚠️ Ver Relatórios Sigilosos Nível 3",
              fg_color="darkred",
              hover_color="red",
              command=lambda n=n: self.exibir_tabela_dados(n),
          )
        else:
          btn = ctk.CTkButton(
              self.container,
              text=f"Ver Dados de Nível {n}",
              command=lambda n=n: self.exibir_tabela_dados(n),
          )
        btn.pack(pady=5)

    self.adicionar_botao_sair()

    self.frame_tabela = ctk.CTkFrame(self.container)
    self.frame_tabela.pack(fill="both", expand=True, pady=10)

    if nivel == 1:
      self.exibir_tabela_dados(1)

  def exibir_tabela_dados(self, nivel_solicitado):
    if nivel_solicitado > self.usuario_dados["nivel"]:
      messagebox.showerror(
          "Acesso Negado", "Seu nível de permissão não alcança esses dados!"
      )
      return

    dados = self.buscar_propriedades(self.usuario_dados["nivel"], nivel_solicitado)

    for widget in self.frame_tabela.winfo_children():
      widget.destroy()

    caixa = ctk.CTkTextbox(self.frame_tabela)
    caixa.pack(fill="both", expand=True, padx=5, pady=5)

    texto = f"--- DADOS DE SIGILO NÍVEL {nivel_solicitado} ---\n\n"
    if not dados:
      texto += "Nenhum registro encontrado.\n"
    for item in dados:
      texto += (
          f"Fazenda: {item[0]}\n"
          f"Proprietário: {item[1]}\n"
          f"Local: {item[2]}\n"
          f"Status Agrotóxicos: {item[3]}\n"
          f"Impacto: {item[4]}\n"
      )
      texto += "-" * 50 + "\n"

    caixa.insert("0.0", texto)
    caixa.configure(state="disabled")

  def criar_cabecalho_nivel(self, titulo_texto):
    ctk.CTkLabel(
        self.container,
        text=titulo_texto,
        font=ctk.CTkFont(size=18, weight="bold"),
    ).pack(pady=(10, 5))

  def adicionar_botao_sair(self):
    ctk.CTkButton(
        self.container,
        text="Sair / Trocar Usuário",
        fg_color="gray",
        command=self.mostrar_tela_inicial,
    ).pack(side="bottom", pady=(10, 0))


if __name__ == "__main__":
  app = AppAPS()
  app.mainloop()