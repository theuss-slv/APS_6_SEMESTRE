import os
import sys

import cv2
import numpy as np

from config import PASTA_RAIZ

# Status devolvidos para a interface (e gravados no log)
CONCEDIDO = "Acesso Concedido"
NEGADO = "Acesso Negado"
CANCELADO = "Cancelado"
ERRO = "Erro"


def _abrir_camera():
  """Abre a webcam priorizando a câmara externa (índice 1) e depois a integrada (índice 0)."""
  cam = None
  for idx in [1, 0]:
    if sys.platform == "win32":
      cam = cv2.VideoCapture(idx, cv2.CAP_DSHOW)
    if cam is None or not cam.isOpened():
      if cam is not None:
        cam.release()
      cam = cv2.VideoCapture(idx)

    if cam is not None and cam.isOpened():
      break

  if cam is None or not cam.isOpened():
    if cam is not None:
      cam.release()
    return None

  cam.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
  cam.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
  for _ in range(15):
    cam.read()
  return cam


def _capturar_frame(
    mensagem_instrucao="Centralize o rosto no meio e pressione ESPACO"
):
  """Mostra a câmara e devolve o frame limpo quando o utilizador aperta ESPAÇO."""
  cam = _abrir_camera()
  if cam is None:
    return (
        None,
        "Não foi possível aceder à câmara! Verifique as permissões do sistema.",
    )

  frame_capturado = None
  while True:
    ret, frame = cam.read()
    if not ret or frame is None:
      break

    frame_limpo = frame.copy()

    cv2.putText(
        frame,
        mensagem_instrucao,
        (20, 40),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.55,
        (0, 255, 0),
        2,
    )
    cv2.putText(
        frame,
        "Pressione ESC para Cancelar",
        (20, 80),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.55,
        (0, 0, 255),
        2,
    )
    cv2.imshow("Autenticacao Biometrica - MMA", frame)

    key = cv2.waitKey(1) & 0xFF
    if key == 32:  # ESPAÇO
      frame_capturado = frame_limpo
      break
    elif key == 27:  # ESC
      break

  cam.release()
  cv2.destroyAllWindows()
  cv2.waitKey(1)
  return frame_capturado, None


def cadastrar_novo_rosto(username):
  """Abre a webcam para capturar e salvar a foto de cadastro do utilizador 100% offline."""
  diretorio_fotos = os.path.join(PASTA_RAIZ, "fotos")
  if not os.path.exists(diretorio_fotos):
    os.makedirs(diretorio_fotos, exist_ok=True)

  caminho_foto = os.path.join(diretorio_fotos, f"{username.lower()}.jpg")

  frame, erro_camera = _capturar_frame(
      "Posicione o rosto para CADASTRO e pressione ESPACO"
  )
  if erro_camera:
    return False, erro_camera
  if frame is None:
    return False, "Cadastro cancelado pelo utilizador."

  cv2.imwrite(caminho_foto, frame)
  return True, f"Rosto cadastrado com sucesso em: {caminho_foto}"


def _isolar_centro_rosto(img):
  """Recorta estritamente a região central onde o rosto se posiciona."""
  h, w, _ = img.shape
  y1, y2 = int(h * 0.2), int(h * 0.8)
  x1, x2 = int(w * 0.3), int(w * 0.7)
  rosto = img[y1:y2, x1:x2]
  return cv2.resize(rosto, (150, 150))


def autenticar_webcam(caminho_foto_cadastro):
  """Autenticação biométrica baseada em recorte central rigoroso e comparação combinada."""
  nome_base = os.path.splitext(os.path.basename(caminho_foto_cadastro))[
      0
  ].lower()

  diretorio_fotos = os.path.join(PASTA_RAIZ, "fotos")
  if not os.path.exists(diretorio_fotos):
    diretorio_fotos = os.path.abspath("fotos")

  caminhos_para_testar = []
  if os.path.exists(diretorio_fotos):
    for f in os.listdir(diretorio_fotos):
      f_lower = f.lower()
      if f_lower.startswith(nome_base) and f_lower.endswith(
          (".jpg", ".jpeg", ".png")
      ):
        caminhos_para_testar.append(os.path.join(diretorio_fotos, f))

  if not caminhos_para_testar:
    caminho_abs = (
        caminho_foto_cadastro
        if os.path.isabs(caminho_foto_cadastro)
        else os.path.join(PASTA_RAIZ, caminho_foto_cadastro)
    )
    if os.path.exists(caminho_abs):
      caminhos_para_testar.append(caminho_abs)

  if not caminhos_para_testar:
    return (
        ERRO,
        f"Nenhuma foto de referência encontrada para o utilizador '{nome_base}'.",
    )

  frame, erro_camera = _capturar_frame(
      "Centralize o rosto no meio e pressione ESPACO"
  )
  if erro_camera:
    return ERRO, erro_camera
  if frame is None:
    return CANCELADO, "Leitura biométrica cancelada pelo utilizador."

  rosto_cap = _isolar_centro_rosto(frame)
  cap_gray = cv2.cvtColor(rosto_cap, cv2.COLOR_BGR2GRAY)
  cap_hsv = cv2.cvtColor(rosto_cap, cv2.COLOR_BGR2HSV)

  melhor_score = 0.0
  for caminho_ref in caminhos_para_testar:
    img_ref = cv2.imread(caminho_ref)
    if img_ref is None:
      continue

    rosto_ref = _isolar_centro_rosto(img_ref)
    ref_gray = cv2.cvtColor(rosto_ref, cv2.COLOR_BGR2GRAY)
    ref_hsv = cv2.cvtColor(rosto_ref, cv2.COLOR_BGR2HSV)

    resultado = cv2.matchTemplate(cap_gray, ref_gray, cv2.TM_CCOEFF_NORMED)
    _, score_corr, _, _ = cv2.minMaxLoc(resultado)

    hist_ref = cv2.calcHist([ref_hsv], [0, 1], None, [30, 32], [0, 180, 0, 256])
    hist_cap = cv2.calcHist([cap_hsv], [0, 1], None, [30, 32], [0, 180, 0, 256])
    cv2.normalize(hist_ref, hist_ref, 0, 1, cv2.NORM_MINMAX)
    cv2.normalize(hist_cap, hist_cap, 0, 1, cv2.NORM_MINMAX)
    score_hist = cv2.compareHist(hist_ref, hist_cap, cv2.HISTCMP_CORREL)

    score_total = (score_corr * 0.6) + (max(0, score_hist) * 0.4)

    if score_total > melhor_score:
      melhor_score = score_total

  print(
      f"📊 Índice de Similaridade Combinado (Centro do Rosto):"
      f" {melhor_score:.2f}"
  )

  if melhor_score > 0.35:
    return CONCEDIDO, "Biometria confirmada! Acesso liberado."
  else:
    return (
        NEGADO,
        f"Rosto não reconhecido! (Pontuação: {melhor_score:.2f} - Necessário >"
        " 0.35)",
    )