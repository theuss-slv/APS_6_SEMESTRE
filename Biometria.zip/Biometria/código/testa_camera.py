import cv2

print("A tentar abrir a câmara...")
cam = cv2.VideoCapture(0, cv2.CAP_DSHOW)
if not cam.isOpened():
  print("Índice 0 com DSHOW falhou, a tentar índice 0 normal...")
  cam = cv2.VideoCapture(0)

if not cam.isOpened():
  print("❌ Erro: Não foi possível aceder à câmara em nenhum índice.")
else:
  print(
      "✅ Câmara aberta com sucesso! Pressione a tecla 'q' na janela da câmara"
      " para fechar."
  )
  while True:
    ret, frame = cam.read()
    if not ret:
      print("Erro ao ler o fluxo da câmara.")
      break
    cv2.imshow("Teste de Camara", frame)
    if cv2.waitKey(1) & 0xFF == ord("q"):
      break
  cam.release()
  cv2.destroyAllWindows()