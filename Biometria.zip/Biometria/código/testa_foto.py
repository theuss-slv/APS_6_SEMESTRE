import os
import sys
from deepface import DeepFace

PASTA_CODIGO = os.path.dirname(os.path.abspath(__file__))
PASTA_RAIZ = os.path.dirname(PASTA_CODIGO)
PASTA_FOTOS = os.path.join(PASTA_RAIZ, "fotos")

# Escolha a foto que deseja testar: 'Leonardo.jpg', 'Guilherme.jpg' ou 'Eduardo.jpg'
FOTO_TESTE = os.path.join(PASTA_FOTOS, "Leonardo.jpg")

print(f"🔍 Verificando foto: {FOTO_TESTE}")

if not os.path.exists(FOTO_TESTE):
  print("❌ O arquivo da foto NÃO existe nesse caminho!")
  sys.exit()

try:
  faces = DeepFace.extract_faces(img_path=FOTO_TESTE, enforce_detection=True)
  print(
      f"✅ SUCESSO! A IA detectou {len(faces)} rosto(s) na foto de"
      " referência."
  )
  print("A foto está perfeita para ser usada no sistema.")
except Exception as e:
  print("⚠️ A IA NÃO conseguiu identificar um rosto claro nesta foto.")
  print(f"Detalhe do erro: {e}")
  print(
      "\n💡 Dica: Substitua essa imagem por uma foto tirada de frente,"
      " bem iluminada e sem sombras pesadas."
  )