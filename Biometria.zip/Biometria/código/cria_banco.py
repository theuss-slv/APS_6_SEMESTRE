import argparse
import os
import sqlite3
from contextlib import closing

from config import CAMINHO_BANCO, PASTA_FOTOS


def foto(nome_arquivo):
    """Guarda o caminho RELATIVO à pasta raiz (funciona se o projeto mudar de lugar)."""
    return f"fotos/{nome_arquivo}"


def inicializar_banco(forcar=False):
    print(f"📍 Banco em: {CAMINHO_BANCO}")

    if not os.path.isdir(PASTA_FOTOS):
        print(f"⚠️ Pasta de fotos não encontrada: {PASTA_FOTOS}")

    if os.path.exists(CAMINHO_BANCO):
        if not forcar:
            resp = input(
                "⚠️ O banco já existe e será APAGADO (inclusive os logs). "
                "Continuar? (s/N): "
            )
            if resp.strip().lower() != "s":
                print("Operação cancelada. Nada foi alterado.")
                return
        try:
            os.remove(CAMINHO_BANCO)
            print("🗑️ Banco antigo removido.")
        except OSError as e:
            print(f"⚠️ Não foi possível apagar o banco (está aberto em outro programa?): {e}")
            return

    with closing(sqlite3.connect(CAMINHO_BANCO)) as conn:
        with conn:  # commit automático (ou rollback se der erro)
            conn.execute("""
                CREATE TABLE usuarios (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    nome_completo TEXT NOT NULL,
                    cargo TEXT NOT NULL,
                    nivel_acesso INTEGER NOT NULL,
                    foto_path TEXT
                )
            """)

            conn.execute("""
                CREATE TABLE propriedades (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nome_fazenda TEXT NOT NULL,
                    proprietario TEXT NOT NULL,
                    localizacao TEXT NOT NULL,
                    nivel_sigilo INTEGER NOT NULL,
                    agrotoxico_proibido TEXT,
                    impacto_hidrico TEXT
                )
            """)

            # data_hora agora no horário local (antes era UTC)
            conn.execute("""
                CREATE TABLE logs_acesso (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL,
                    nivel_usuario INTEGER NOT NULL,
                    status TEXT NOT NULL,
                    data_hora DATETIME DEFAULT (datetime('now', 'localtime'))
                )
            """)

            usuarios_iniciais = [
                ("eduardo", "Eduardo Felix", "Analista de Dados", 1, foto("Eduardo.jpg")),
                ("guilherme", "Guilherme Altomar", "Diretor de Divisão", 2, foto("Guilherme.jpg")),
                ("leonardo", "Leonardo Santos", "Ministro do Meio Ambiente", 3, foto("Leonardo.jpg")),
            ]
            conn.executemany(
                """
                INSERT INTO usuarios (username, nome_completo, cargo, nivel_acesso, foto_path)
                VALUES (?, ?, ?, ?, ?)
                """,
                usuarios_iniciais,
            )

            propriedades_iniciais = [
                (
                    "Fazenda Boa Vista", "Antônio Rosa", "Bacia do Rio Doce - MG", 1,
                    "Nenhum detectado", "Sem alteração nos lençóis freáticos",
                ),
                (
                    "Fazenda Progresso", "Roberto Diniz", "Bacia do Rio São Francisco - BA", 2,
                    "Em Investigação", "Baixa poluição residual",
                ),
                (
                    "Fazenda Santa Helena", "Marcos Guimarães", "Bacia do Rio Xingu - MT", 3,
                    "PROIBIDO: Endossulfano",
                    "CRÍTICO: Contaminação grave do lençol freático",
                ),
            ]
            conn.executemany(
                """
                INSERT INTO propriedades
                    (nome_fazenda, proprietario, localizacao, nivel_sigilo,
                     agrotoxico_proibido, impacto_hidrico)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                propriedades_iniciais,
            )

    print("✅ SUCESSO! O arquivo 'mma_sistema.db' foi gerado.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Cria o banco do sistema MMA.")
    parser.add_argument(
        "--recriar",
        action="store_true",
        help="apaga o banco existente sem perguntar",
    )
    args = parser.parse_args()
    inicializar_banco(forcar=args.recriar)